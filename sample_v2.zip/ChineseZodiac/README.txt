Yuqing Qiu	| A00985057	| 1B	| yqiu25@my.bcit.com
Ashley Qin	| A00936992	| 1B	| zqin6@my.bcit.com

completed:

not completed:

major challenges:
 